# AFTER SCHOOL — Android Game

Proyek game 2D anime sekolah sederhana yang dibungkus menjadi aplikasi Android menggunakan WebView.

## Build APK lewat GitHub Actions

1. Buat repository GitHub baru.
2. Ekstrak seluruh isi ZIP ini.
3. Upload seluruh file dan folder ke repository (pastikan folder `.github/workflows` ikut ter-upload).
4. Commit ke branch `main` atau `master`.
5. Buka tab **Actions** di repository.
6. Pilih workflow **Build Android APK** lalu klik **Run workflow**, atau tunggu build berjalan setelah push.
7. Setelah selesai, buka run yang berhasil dan unduh artifact **After-School-Android-APK**.
8. Ekstrak artifact ZIP untuk mendapatkan `app-debug.apk`, lalu pasang di perangkat Android.

## Kontrol

- ◀ / ▶ : bergerak
- ⚔ SERANG : menyerang
- ↗ HINDAR : menghindar
- Keyboard: A/D atau panah, J untuk serang, K untuk hindar, Space untuk lanjut dialog.

## Catatan

- Ini adalah APK debug untuk uji coba, belum ditandatangani sebagai rilis Play Store.
- Workflow memerlukan akses internet untuk mengunduh Android Gradle Plugin dan Android SDK.
- Tidak memerlukan API key atau secret GitHub.
